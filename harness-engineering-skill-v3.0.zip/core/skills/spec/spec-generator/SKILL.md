---
id: spec-generator
name: "Spec Generator — 规范文档生成器"
stage: spec
roles: [product-owner]
pattern: template-filling
mandatory: true
depends: [brainstorming]
version: "3.0"
---

# Spec Generator — 设计文档生成器

> **设计模式**：Generator（模板填充式生成）
> **阶段**：定义
> **角色**：Product Owner
> **触发**：/spec（与 brainstorming 协同）

## 触发条件

| 触发场景 | 触发方式 | 说明 |
|---------|---------|------|
| brainstorming 采访完成 | brainstorming 输出 design_decisions | 自动进入文档生成 |
| 用户输入 `/spec` | 显式请求 | 手动触发设计文档生成 |
| deep-requirements 完成 | deep-requirements 输出深度需求 | 增量补充设计文档 |

**不触发场景**：尚未完成 brainstorming 采访、用户明确跳过 spec 阶段。

## 前置依赖

| 依赖项 | 来源 | 必需性 | 说明 |
|-------|------|-------|------|
| brainstorming 采访结果 | brainstorming Skill 输出 | 必需 | 提供变量填充数据源 |
| spec-template.md | `assets/spec-template.md` | 必需 | 文档结构模板 |
| 用户审批 | MCP 检查点 TYPE_B | 必需 | 文档生成后需用户确认 |

## 核心原则

1. **模板驱动**：使用 assets/spec-template.md 保证输出一致性
2. **变量填充**：从 brainstorming 采访结果中提取变量
3. **严格遵循模板**：不遗漏任何章节，不添加模板外的内容
4. **审批后定稿**：生成文档后必须等待用户审批才能进入下一阶段

## 执行流程

### Step 1：读取模板

读取 `assets/spec-template.md` 获取文档结构。

验证模板包含以下必要章节：
- [ ] 元信息（日期、作者、版本）
- [ ] 背景与目标
- [ ] 目标用户
- [ ] 核心场景
- [ ] 受影响模块
- [ ] 技术风险
- [ ] 验收标准
- [ ] 方案对比
- [ ] 推荐方案

### Step 2：收集变量

从 brainstorming 采访结果中提取以下变量：

| 变量 | 来源 | 必填 | 提取规则 |
|------|------|------|---------|
| `{{topic}}` | 功能名称 | ✅ | 从 brainstorming 标题或用户原始需求提取 |
| `{{date}}` | 当前日期 | ✅ | YYYY-MM-DD 格式 |
| `{{target_user}}` | 采访 Q1 回答 | ✅ | 直接引用，保持用户原话 |
| `{{core_scenarios}}` | 采访 Q2 回答 | ✅ | 整理为场景列表 |
| `{{affected_modules}}` | 采访 Q3 回答 | ✅ | 列出受影响的代码模块 |
| `{{tech_risks}}` | 采访 Q4 回答 | ⚠️ | 如无回答则标注"待评估" |
| `{{acceptance_criteria}}` | 采访 Q5 回答 | ✅ | 转为可验证的 AC 列表 |
| `{{solution_a}}` | 方案 A 描述 | ✅ | 从方案对比中提取 |
| `{{solution_b}}` | 方案 B 描述 | ⚠️ | 如无第二方案则标注"仅单一方案" |
| `{{recommended}}` | 推荐方案 | ✅ | 标注推荐理由 |

**变量缺失处理**：
- 必填变量缺失 → 回到 brainstorming 补充采访
- 可选变量缺失 → 填入默认占位文本（如"待评估"、"仅单一方案"）

### Step 3：填充模板

将变量填入模板，严格遵循模板结构。

填充规则：
1. 保持模板的章节顺序和层级不变
2. 变量值直接替换 `{{variable}}` 占位符
3. 列表类变量（如 core_scenarios）展开为 Markdown 列表
4. 不添加模板中不存在的章节

### Step 4：生成验收标准

将采访 Q5 的回答转化为结构化的验收标准：

```markdown
## 验收标准

| AC-ID | 验收标准 | 优先级 | 验证方式 |
|-------|---------|--------|---------|
| AC-001 | <验收标准描述> | P0 | <自动化/手动> |
| AC-002 | <验收标准描述> | P0 | <自动化/手动> |
| AC-003 | <验收标准描述> | P1 | <自动化/手动> |
```

### Step 5：用户审批

使用 MCP 检查点 TYPE_B (APPROVAL) 等待用户确认：

```
📍 CHECKPOINT [SPEC-APPROVAL] — 设计文档审批
📄 文档路径: .harness/specs/YYYY-MM-DD-<topic>-design.md
```

用户可选择：
- ✅ 批准 → 文档定稿，进入 plan 阶段
- ✏️ 修改 → 根据反馈修改后重新审批
- ❌ 驳回 → 回到 brainstorming 重新采访

### Step 6：输出

输出到：`.harness/specs/YYYY-MM-DD-<topic>-design.md`

## 产出物

| 产出物 | 路径模板 | 格式 | 说明 |
|-------|---------|------|------|
| 设计文档 | `.harness/specs/YYYY-MM-DD-<topic>-design.md` | Markdown | 基于模板生成的标准化设计文档 |
| 验收标准表 | 设计文档内嵌 | Markdown 表格 | 可验证的 AC 列表 |
| 方案对比表 | 设计文档内嵌 | Markdown 表格 | 至少 2 种方案的优劣对比 |

## 失败处理

| 失败场景 | 处理方式 | 恢复策略 |
|---------|---------|---------|
| brainstorming 采访结果缺失 | 停止生成，提示用户先执行 brainstorming | 执行 brainstorming 后重新触发 |
| 模板文件不存在 | 报错并使用内置最小模板兜底 | 创建 spec-template.md 后重新生成 |
| 必填变量缺失 | 标注缺失变量，回到 brainstorming 补充 | 补充采访对应问题后重新填充 |
| 用户驳回设计文档 | 记录驳回原因，回到 Step 2 重新收集变量 | 根据反馈修改后重新审批 |
| 文件写入失败 | 检查 .harness/specs/ 目录权限 | 创建目录后重新输出 |
| 日期格式冲突（同名文件已存在） | 在文件名中追加序号或时间戳 | 确认覆盖或使用新文件名 |

## 质量门禁

| 门禁项 | 检查方式 | 通过标准 |
|-------|---------|---------|
| 设计文档存在 | 文件系统检查 | `.harness/specs/` 下有对应文件 |
| 文档已审批 | 文档状态字段 | 状态为"已审批" |
| 验收标准存在 | 内容搜索 | 文档中有 ≥1 条验收标准 |
| 模板章节完整 | 结构校验 | 模板定义的所有章节均存在 |
| 变量无残留 | 正则匹配 | 无 `{{...}}` 占位符残留 |

## 与其他 Skill 的协作

| 协作 Skill | 协作方式 |
|-----------|---------|
| brainstorming | brainstorming 采集变量 → spec-generator 生成文档 |
| deep-requirements | deep-requirements 深度分析 → spec-generator 增量补充 |
| writing-plans | spec-generator 输出 → writing-plans 拆微任务 |
| office-hours | office-hours 诊断 → brainstorming 采访 → spec-generator 生成 |
