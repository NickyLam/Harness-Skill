#!/bin/bash
set -e

echo "🔍 Checking Spec Gate..."

# 检查 PRD 文档
if [ ! -f "docs/PRD.md" ]; then
  echo "❌ FAIL: PRD.md not found"
  exit 1
fi

# 检查需求完整性
echo "  → Checking requirement completeness..."
MISSING_SECTIONS=$(grep -c "TODO\|FIXME\|待补充" docs/PRD.md || true)
if [ "$MISSING_SECTIONS" -gt 0 ]; then
  echo "⚠️ WARNING: $MISSING_SECTIONS incomplete sections in PRD.md"
fi

# 检查验收标准
if ! grep -q "验收标准\|Acceptance Criteria" docs/PRD.md; then
  echo "❌ FAIL: No acceptance criteria found"
  exit 1
fi

echo "✅ Spec Gate passed"
exit 0
