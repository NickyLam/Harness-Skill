---
id: gsd
name: "GSD — Getting Stuff Done 上下文引擎"
description: "When the user mentions wave execution, subagent orchestration, parallel tasks, complex multi-step workflow, or needs to break down large tasks into atomic micro-tasks, ALWAYS use this skill. Provides wave-based execution with mandatory user checkpoints."
stage: cross-cutting
roles: [orchestrator, coordinator]
pattern: wave-execution
mandatory: false
depends: []
version: "3.0"
compatibility:
  tools: [AskUserQuestion, Task, Read, Write]
  dependencies: []
---

# GSD — Getting Stuff Done（精简版）

> 上下文引擎层：解决 AI 长时任务质量退化问题

## 核心原则

1. **子代理隔离**：每个子任务启动独立上下文，避免上下文腐烂
2. **波次编排**：独立任务并行执行，依赖任务顺序执行
3. **用户确认优先**：所有执行计划必须经用户明确确认后才能启动
4. **上下文监控**：实时监控上下文用量，窗口不够时自动告警
5. **持久化优先**：关键信息必须写入文件，不依赖上下文传递

## 触发条件

- 超过 5 个步骤的复杂任务
- 需要多轮迭代的开发任务
- 涉及多文件修改的重构任务
- 用户明确要求"波次执行"或"子代理开发"

## 工作流

### Step 1：任务拆分

将大任务拆分为 ≤5分钟的原子微任务：

- 每个微任务应可独立验证
- 明确每个微任务的输入（依赖）和输出（交付物）
- 标注任务间依赖关系

**检查点**: PLAN-TASKS（MANDATORY）
- 生成任务拆分表格
- 调用 AskUserQuestion 确认
- 写入 `.harness/checkpoints/plan-task-breakdown.md`

> 完整检查点协议见 [references/checkpoint-protocol.md](references/checkpoint-protocol.md)

### Step 2：波次编排

```
Wave 1: [T1] [T2] [T3]     ← 无依赖，并行执行
Wave 2: [T4] [T5]           ← 依赖 Wave 1 的部分输出
Wave 3: [T6]                ← 依赖 Wave 2
...
```

- 同一 Wave 内的任务可并行（通过 Task tool 启动多个子代理）
- 跨 Wave 的任务必须等待前置 Wave 完成
- 每个 Wave 完成后做一次汇总验证

**检查点**: PLAN-WAVE（MANDATORY）
- 生成 Wave 可视化计划
- 调用 AskUserQuestion 确认
- 写入 `.harness/checkpoints/plan-wave-schedule.md`

### Step 3：子代理执行（受 Pre-Execution Gate 保护）

**Pre-Execution Gate 触发条件**（满足任一）：
- 首次运行 Wave Executor
- 总任务数 ≥ 3
- Wave 数 ≥ 2
- 距离 PLAN-WAVE 确认时间超过 10 分钟
- 计划有变更

**子代理启动规范**：

```
Task tool 调用参数:
  subagent_type: "search"
  description: "Implement T{N}.{M}: {任务描述}"
  prompt: |
    你是 Implementer 子代理。
    
    ## 任务
    {任务描述}
    
    ## TDD 流程（强制）
    1. RED: 先写失败的测试
    2. GREEN: 写最少代码让测试通过
    3. REFACTOR: 在测试保护下优化
    
    ## 约束
    - 输出文件: {输出路径}
    - 依赖文件: {依赖路径}
    - 只修改任务范围内的文件
    
    ## 完成标准
    - 输出文件已创建且内容正确
    - 测试全部通过
    - 未修改范围外文件
```

### Step 4：上下文监控

- 上下文使用超过 60%：发出警告 + 询问是否准备切换
- 上下文使用超过 80%：强制调用 AskUserQuestion 确认切换策略
- 任何重要中间结果必须持久化到文件

## 错误处理

### 子代理失败处理

- **子代理失败**：读取子代理输出中的错误信息，分析原因后决定是否重试（最多 2 次）或调整任务拆分
- **重试前的确认**：如果失败率 > 30%，触发额外确认

### Wave 验证失败处理

- **Wave 验证失败**：暂停执行，向用户展示失败原因
- **强制等待决策**：调用 AskUserQuestion 确认下一步操作

### 上下文不足处理

- **上下文不足**：当主代理上下文接近 80% 时
- **必须先确认再切换**：调用 AskUserQuestion 确认切换策略

## 输出规范

### 波次计划文件格式

```markdown
# <项目名> - 波次实施计划

## 元信息
- 创建时间: {timestamp}
- 确认时间: {timestamp} (用户确认)
- 状态: APPROVED / PENDING / CANCELLED

## Wave 1: <阶段名>（并行）
- [T1.1] 任务描述 → 独立子代理 → 输出: 文件路径
- [T1.2] 任务描述 → 独立子代理 → 输出: 文件路径

## Wave 2: <阶段名>（依赖 Wave 1）
- [T2.1] 任务描述 → 依赖 T1.x → 输出: 文件路径

## Checkpoint 记录
- PLAN-TASKS: {timestamp}
- PLAN-WAVE: {timestamp}
- EXEC-PRE-RUN: {timestamp} (如触发)

## 验证点
- Wave 1 完成 → 验证条件
- Wave 2 完成 → 验证条件
```

## 与其他 Skill 的协作

| 协作 Skill | 协作方式 |
|-----------|---------|
| writing-plans | 产出微任务列表，GSD 负责编排执行 |
| subagent-driven-development | GSD 提供子代理隔离基础设施 |
| TDD | 每个子代理内部遵循 TDD 流程 |
| /qa | 最终 Wave 完成后，/qa 接手端到端验证 |
| brainstorming | spec 阶段的采访结果作为输入 |

## 禁止事项

| # | 禁止行为 | 后果 |
|---|----------|------|
| G-1 | 无 PLAN-TASKS 确认就进入 Wave 编排 | Level-2 Block |
| G-2 | 无 PLAN-WAVE 确认就启动子代理 | Level-2 Block |
| G-3 | 大型执行（≥3 tasks）无 EXEC-PRE-RUN 就启动 | Level-2 Block |
| G-4 | 使用过期的确认（>30min） | Level-2 Block |
| G-5 | Wave 失败后不询问就自动重试 | Warning |
| G-6 | 上下文不足时不确认就切换 | Level-2 Block |

## 注意事项

- 子代理之间通过文件系统传递信息，不依赖上下文
- 每个 Wave 完成后做一次 git commit（原子提交）
- 如果子代理失败，主代理分析原因后**先确认再**决定重试或调整计划
- 避免在主代理上下文中保留大量中间数据
- **所有执行必须经过用户确认，无例外**

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-04-28 | 初始版本 |
| 2.0.0 | 2026-04-30 | 集成 MCP 协议，检查点升级为强制，添加 Pre-Execution Gate |
