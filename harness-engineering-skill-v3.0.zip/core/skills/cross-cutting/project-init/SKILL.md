---
id: project-init
name: "Project Init — 项目快速初始化与脚手架"
stage: cross-cutting
roles: [architect, implementer]
pattern: scaffolding
mandatory: false
depends: []
version: "3.1"
---

# Project Init — 项目快速初始化与脚手架

> **设计模式**：Scaffolding（项目脚手架）
> **阶段**：Cross-Cutting（项目启动时）
> **触发**：`/init` 或新建项目时
> **目标**：5分钟内生成完整可运行的项目骨架

## 核心原则

1. **零配置起步**：提供合理的默认配置，用户无需手动调整即可运行
2. **最佳实践内置**：默认包含 ESLint、Prettier、TypeScript 严格模式、Git Hooks
3. **模块化架构**：清晰的项目结构，支持后续扩展
4. **可定制性**：所有配置都可以通过交互式选项覆盖默认值
5. **文档即代码**：生成的同时创建必要的 README 和配置说明

## 触发条件

- 用户输入 `/init` 或 `project-init`
- 新建空目录并希望快速搭建项目框架
- 需要创建符合 Harness 工程规范的新项目原型

## DnP 模式决策树（Design 'n' Pattern）

```
你要创建什么类型的项目？
├─ 前端 Web 应用？
│  ├─ React + TypeScript？→ 使用 [React Template]
│  ├─ Vue + TypeScript？ → 使用 [Vue Template]
│  └─ 纯 HTML/CSS/JS？   → 使用 [Static Template]
│
├─ 后端 API 服务？
│  ├─ Node.js + Express？ → 使用 [Node.js API Template]
│  ├─ Python + FastAPI？  → 使用 [Python API Template]
│  └─ Go + Gin？          → 使用 [Go API Template]
│
├─ 全栈应用？
│  └─ Next.js / Nuxt.js？ → 使用 [Full-Stack Template]
│
└─ 库/包（npm/pip）？
   └─ TypeScript Library？ → 使用 [Library Template]
```

## 完整执行流程（6步）

### Step 1：交互式需求采集

```bash
# 启动交互式初始化
harness init

# 输出示例：
? Project name: my-awesome-project
? Description: A web application for managing tasks
? Tech stack: (Use arrow keys)
❯ React + TypeScript
  Vue + TypeScript
  Node.js + Express
  Python + FastAPI
? Features: (Press space to select)
❯ ◉ ESLint + Prettier
  ◉ Git Hooks (Husky)
  ◉ Testing (Jest/Vitest)
  ◉ CI/CD (GitHub Actions)
  ◉ Docker Support
? Package manager: npm (or pnpm/yarn)
```

### Step 2：生成项目结构

```bash
# 自动生成的目录结构（以 React + TypeScript 为例）
my-awesome-project/
├── .github/
│   └── workflows/
│       ├── ci.yml              # CI 流水线
│       └── cd.yml              # CD 部署流水线
├── .husky/                     # Git Hooks
├── .vscode/                    # VS Code 配置
│   ├── settings.json           # 编辑器设置
│   └── extensions.json         # 推荐扩展
├── src/
│   ├── components/             # 可复用组件
│   │   └── .gitkeep
│   ├── pages/                  # 页面组件
│   │   └── Home.tsx
│   ├── hooks/                  # 自定义 Hooks
│   │   └── .gitkeep
│   ├── utils/                  # 工具函数
│   │   └── .gitkeep
│   ├── types/                  # TypeScript 类型定义
│   │   └── index.ts
│   ├── styles/                 # 全局样式
│   │   └── globals.css
│   ├── App.tsx                 # 应用入口组件
│   └── main.tsx                # 应用入口
├── __tests__/                  # 测试文件
│   └── App.test.tsx
├── .dockerignore               # Docker 忽略文件
├── .editorconfig               # 编辑器配置
├── .env.example                # 环境变量模板
├── .eslintrc.js                # ESLint 配置
├── .gitignore                  # Git 忽略规则
├── .prettierrc                 # Prettier 配置
├── Dockerfile                  # Docker 构建文件
├── docker-compose.yml          # Docker Compose 开发环境
├── index.html                  # HTML 入口
├── package.json                # 项目依赖
├── tsconfig.json               # TypeScript 配置
├── vite.config.ts              # Vite 构建配置
├── README.md                   # 项目文档
└── LICENSE                     # 许可证
```

### Step 3：生成核心配置文件

#### package.json（示例）

```json
{
  "name": "my-awesome-project",
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "preview": "vite preview",
    "test": "vitest",
    "test:coverage": "vitest run --coverage",
    "format": "prettier --write \"src/**/*.{ts,tsx,css}\"",
    "prepare": "husky"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1"
  },
  "devDependencies": {
    "@types/react": "^18.3.12",
    "@types/react-dom": "^18.1.0",
    "@typescript-eslint/eslint-plugin": "^8.8.0",
    "@typescript-eslint/parser": "^8.8.0",
    "@vitejs/plugin-react": "^4.3.3",
    "eslint": "^9.13.0",
    "eslint-plugin-react-hooks": "^5.0.0",
    "eslint-plugin-react-refresh": "^0.4.14",
    "husky": "^9.1.7",
    "lint-staged": "^15.2.10",
    "prettier": "^3.3.3",
    "typescript": "~5.6.2",
    "vite": "^6.0.1",
    "vitest": "^2.1.6",
    "@testing-library/react": "^16.0.1",
    "@testing-library/jest-dom": "^6.6.3",
    "jsdom": "^25.0.1"
  },
  "lint-staged": {
    "*.{ts,tsx}": [
      "eslint --fix",
      "prettier --write"
    ]
  }
}
```

#### tsconfig.json（严格模式）

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "isolatedModules": true,
    "moduleDetection": "force",
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedIndexedAccess": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["src/*"]
    }
  },
  "include": ["src"]
}
```

#### .eslintrc.js（推荐规则）

```javascript
module.exports = {
  root: true,
  env: { browser: true, es2020: true },
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'plugin:react-hooks/recommended',
    'plugin:react-refresh',
  ],
  ignorePatterns: ['dist', '.eslintrc.cjs'],
  parser: '@typescript-eslint/parser',
  plugins: ['react-refresh'],
  rules: {
    '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
    '@typescript-eslint/no-explicit-any': 'warn',
    'react-refresh/only-export-components': ['warn', { allowConstantExport: true }],
    'no-console': ['warn', { allow: ['warn', 'error'] }],
  },
};
```

### Step 4：安装依赖并验证

```bash
# 安装所有依赖
npm install

# 验证 TypeScript 编译
npx tsc --noEmit

# 运行 lint 检查
npm run lint

# 运行测试
npm run test

# 尝试构建
npm run build
```

### Step 5：生成初始 Git 提交

```bash
# 初始化 Git 仓库
git init

# 创建初始提交
git add .
git commit -m "chore: initialize project with harness-scaffold

- React + TypeScript + Vite setup
- ESLint + Prettier configured
- Husky + lint-staged for pre-commit hooks
- Vitest for testing
- GitHub Actions CI/CD workflows
- Docker support included"

# 推送到远程仓库（可选）
git remote add origin git@github.com:username/my-awesome-project.git
git push -u origin main
```

### Step 6：输出快速上手指南

```markdown
## ✅ 项目已成功初始化！

### 下一步操作

\`\`\`bash
# 1. 启动开发服务器
npm run dev

# 2. 在浏览器中打开 http://localhost:5173

# 3. 开始开发你的功能！

# 4. 常用命令
npm run dev       # 启动开发服务器
npm run build     # 构建生产版本
npm run test      # 运行测试
npm run lint      # 代码检查
npm run format    # 格式化代码
\`\`\`

### 项目特性

- ⚡️ Vite - 极速的开发体验
- 🔷 TypeScript - 类型安全
- 🎨 ESLint + Prettier - 代码质量保证
- 🔄 Husky + lint-staged - Git Hooks 自动化
- 🧪 Vitest - 快速单元测试
- 🐳 Docker - 容器化支持
- 🚀 GitHub Actions - CI/CD 就绪

### 文档链接

- [Harness Engineering Guide](./docs/harness-guide.md)
- [Contributing Guide](./CONTRIBUTING.md)
- [API Documentation](./docs/api.md) （待补充）

---

Happy coding! 🚀
```

## 模板选项详解

### 1. React + TypeScript 模板（默认）

**适用场景**：单页应用（SPA）、管理后台、复杂交互的 Web 应用

**技术栈**：
- React 18 + TypeScript 5
- Vite 6（构建工具）
- React Router v6（路由）
- TanStack Query v5（数据获取）
- Tailwind CSS v4（样式，可选）

**特殊配置**：
- 路径别名：`@/*` → `src/*`
- 绝对导入支持
- Hot Module Replacement (HMR)

### 2. Node.js API 模板

**适用场景**：RESTful API、GraphQL 服务、微服务后端

**技术栈**：
- Node.js 20 LTS + TypeScript
- Express.js / Fastify
- Prisma ORM（数据库）
- JWT 认证
- Zod（输入验证）

**特殊配置**：
- 环境变量管理（dotenv）
- 结构化日志（pino）
- Swagger/OpenAPI 文档自动生成
- Docker 多阶段构建

### 3. Full-Stack 模板

**适用场景**：需要 SSR 的应用、SEO 友好的网站

**技术栈**：
- Next.js 15 (App Router)
- TypeScript 5
- Prisma ORM
- NextAuth.js（认证）
- shadcn/ui（UI 组件库）

**特殊配置**：
- API Routes 支持
- Middleware（鉴权、重定向）
- ISR（增量静态再生）
- Image Optimization

## 失败处理（8个场景）

| 失败场景 | 检测方式 | 解决方案 | 恢复命令 |
|---------|---------|---------|----------|
| **目录非空** | 检测已有文件 | 提示用户选择：清空/合并/取消 | `rm -rf * .* 2>/dev/null` 或选择其他目录 |
| **依赖安装失败** | npm exit code ≠ 0 | 检查网络/Registry/Node版本 | `npm cache clean --force && npm install` |
| **TypeScript 编译错误** | tsc 报错 | 检查 tsconfig.json 配置 | `npx tsc --showConfig` 查看实际配置 |
| **Git 初始化失败** | 权限问题 | 检查 SSH keys 或切换到 HTTPS | `ssh -T git@github.com` 验证连接 |
| **端口被占用** | EADDRINUSE 错误 | 自动尝试下一个可用端口 | Vite 会自动使用 5174, 5175... |
| **Docker 构建失败** | docker build 报错 | 检查 Dockerfile 语法和基础镜像 | `docker build --progress=plain` 查看详细日志 |
| **测试框架配置错误** | vitest/jest 无法运行 | 检查依赖是否正确安装 | `npx vitest --debug` 进入调试模式 |
| **权限不足（Linux/Mac）** | EACCES 错误 | 使用 sudo 或修复文件权限 | `sudo chown -R $(whoami) .` |

## 产出物（6个关键交付物）

| 产出物 | 路径模板 | 格式 | 说明 | 必要性 |
|-------|---------|------|------|-------|
| 完整项目结构 | 当前目录 | 目录树 | 包含 src/, config, tests 等 | **必需** |
| package.json | `package.json` | JSON | 依赖和脚本定义 | **必需** |
| 配置文件集合 | `*.config.*`, `.eslintrc*` 等 | YAML/JSON/JS | 所有工具链配置 | **必需** |
| README.md | `README.md` | Markdown | 项目文档和快速开始指南 | **必需** |
| Dockerfile | `Dockerfile` | Dockerfile | 容器化构建配置 | 推荐 |
| CI/CD Workflows | `.github/workflows/*.yml` | YAML | GitHub Actions 流水线 | 推荐 |

## 与其他 Skill 的协作矩阵

| 协作 Skill | 协作时机 | 协作内容 | 数据流向 |
|-----------|---------|---------|---------|
| **onboarding** | 项目创建后 | 用户上手指南和团队规范 | 项目结构 → Onboarding 文档 |
| **tdd** | 开发第一个功能前 | TDD 环境配置和测试模板 | 配置 → Test Setup |
| **ci-cd-pipeline** | 项目初始化时 | CI/CD 流水线配置 | 模板 → Workflow 文件 |
| **containerization** | 需要 Docker 时 | Dockerfile 和 docker-compose | 配置 → 容器化文件 |
| **gating** | 后续开发中 | 质量门禁配置集成 | Config → Gate Settings |
| **gsd** | 大型项目拆分任务时 | GSD 配置和工作区设置 | 项目结构 → GSD Setup |

## 质量检查清单（初始化完成后必检）

### 开发环境
- [ ] Node.js ≥ 20.x 已安装 (`node --version`)
- [ ] npm ≥ 10.x 已安装 (`npm --version`)
- [ ] Git 已配置 (`git config user.name/email`)
- [ ] VS Code 已安装推荐扩展

### 项目文件完整性
- [ ] `package.json` 存在且格式正确
- [ ] `tsconfig.json` 存在且 strict mode 开启
- [ ] `.eslintrc.*` 存在且无语法错误
- [ ] `.prettierrc` 存在
- [ ] `.gitignore` 包含 node_modules, dist, .env

### 功能验证
- [ ] `npm run dev` 能正常启动开发服务器
- [ ] `npm run build` 能成功构建
- [ ] `npm run test` 能运行测试（即使没有测试用例）
- [ ] `npm run lint` 通过（0 errors）
- [ ] `npm run format` 能格式化代码

### 版本控制
- [ ] Git 仓库已初始化
- [ ] 初始 commit 已创建
- [ ] 远程仓库已连接（如需要）

## 下一步行动

Project Init 完成后：

1. **开始开发** → 运行 `npm run dev` 启动开发服务器
2. **学习规范** → 阅读 onboarding 文档了解团队约定
3. **编写第一个功能** → 使用 tdd 或 brainstorming 开始需求分析
4. **配置部署** → 使用 ci-cd-pipeline 设置自动化发布流程
5. **团队协作** → 将项目推送到远程仓库邀请成员加入
