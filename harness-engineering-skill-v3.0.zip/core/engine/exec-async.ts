import { exec } from 'child_process';
import { promisify } from 'util';

export const execAsync = promisify(exec);

/**
 * 安全命令执行 — 带输入校验和超时保护
 *
 * 安全策略:
 * 1. 禁止 shell 元字符: | ; ` $() & > < \n 以及换行
 * 2. 禁止空命令
 * 3. 默认超时 120s，可覆盖
 * 4. 强制 cwd 限定工作目录
 */
const DANGEROUS_PATTERN = /[|;`$&><\n\r{}\[\]]/;

export interface SafeExecOptions {
  cwd?: string;
  timeout?: number;
  /** 允许 shell 元字符（仅限受信任的内部调用） */
  allowShellMeta?: boolean;
}

/**
 * 经过安全校验的命令执行包装器
 * @param command 要执行的命令字符串
 * @param options 执行选项
 * @throws SecurityError 当命令包含危险字符时
 */
export function safeExec(
  command: string,
  options: SafeExecOptions = {}
): ReturnType<typeof execAsync> {
  const {
    timeout = 120_000,
    allowShellMeta = false,
  } = options;

  // 安全校验
  if (!command || command.trim().length === 0) {
    return Promise.reject(new Error('Security: empty command rejected'));
  }

  if (!allowShellMeta && DANGEROUS_PATTERN.test(command)) {
    return Promise.reject(
      new Error(`Security: command blocked by safeExec policy (contains disallowed characters): ${command.slice(0, 100)}`)
    );
  }

  // 路径遍历检测
  if (command.includes('..') && /\.\./.test(command)) {
    // 仅在看起来像路径遍历时拒绝（简单启发式）
    const pathTraversalPattern = /\.\.[\/\\]/;
    if (pathTraversalPattern.test(command)) {
      return Promise.reject(
        new Error(`Security: path traversal detected in command: ${command.slice(0, 100)}`)
      );
    }
  }

  return execAsync(command, {
    cwd: options.cwd,
    timeout,
    maxBuffer: 1024 * 1024, // 1MB stdout/stderr 限制
  });
}
