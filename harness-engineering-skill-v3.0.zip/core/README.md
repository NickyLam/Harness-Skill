# Harness Engineering Skill — Core Framework

> **版本**: 2.1.0 (Deep Requirements Edition)
> **架构哲学**: 增量流水线驱动，波次并行执行，能力按需装配，质量门禁守护，经验持续沉淀
> **v2.1.0 新增**: 企业级深度需求分析模块 (deep-requirements)

## 五层架构

```
L5: 治理与记忆层 (Governance + Memory)     — 经验沉淀、成熟度模型、审计追踪
L4: 门控与保障层 (Gating + QA)              — 7-Gate 防御纵深、E2E 验证、Staff Review
L3: 编排与执行层 (Orchestrator + GSD Engine) — 7-Stage Pipeline、Wave 编排、Sub-agent 隔离
L2: 方法论能力库 (Superpowers Capsules)      — 16 个可插拔能力胶囊（含 deep-requirements）
L1: 基础设施层 (Foundation)                  — 项目模板、严格度分级、插件注册
```

## 快速开始

```bash
# 1. 初始化项目
/harness init --template <template-name> --strictness <L1|L2|L3>

# 2. 执行完整流水线
/harness spec → /harness plan → /harness build → /harness test → /harness review → /harness ship

# 3. 单步执行（需要前一阶段通过）
/harness <stage-name>
```

## 核心命令

| 命令 | 阶段 | 角色 | 说明 |
|------|------|------|------|
| `/harness spec` | 定义 | Product Owner | 需求澄清 + 设计文档 |
| `/harness plan` | 规划 | Architect | 任务拆分 + 波次编排 |
| `/harness build` | 构建 | Implementer | TDD 编码 + Wave 并行 |
| `/harness test` | 验证 | Tester | 测试 + E2E + 证据收集 |
| `/harness review` | 评审 | Reviewer | Staff 审查 + 简化分析 |
| `/harness simplify` | 优化 | Reviewer | 代码简化建议 |
| `/harness ship` | 发布 | Shipper | 发布流水线 |

## 目录说明

```
core/
├── pipeline/          # 流水线定义（Stage/Gate/Handoff）
├── roles/             # 角色定义（6 个角色的 SKILL.md + prompts）
├── capsules/          # 能力胶囊库（16 个 Capsule）
│   ├── brainstorming/     # Inversion 采访 + 方案设计 (v3.0 含 DEPTH-GATE)
│   ├── deep-requirements/ # 🆕 企业级深度需求分析 (12问+4审批)
│   │   ├── modules/       # 3 个分析模块 (business-rules, user-journey, edge-cases)
│   │   └── generators/    # 3 个产出生成器 (requirements-doc, gherkin-spec, mermaid-charts)
├── gating/            # 门控层（Gate 定义 + 严格度分级）
├── templates/         # 项目模板（web-react 等）
├── governance/        # 治理层（经验沉淀、成熟度模型）
├── memory/            # 记忆管理规范
└── engine/            # 执行引擎（Wave/回滚/监控）
```

## 兼容性

- AI Agent Runtime: Claude, GPT-4, 及兼容工具调用协议的 Agent
- 项目类型: Web (React/Next/Vue), API (Java/Go/Node), Mobile (Flutter/RN)
- 最小要求: 支持 File Read/Write, Sub-agent (Task tool), Bash execution
