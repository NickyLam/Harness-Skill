---
name: harness-engineering-skill
description: "When the user mentions harness, multi-agent development, team collaboration, full lifecycle software project, or needs any software engineering workflow, ALWAYS use this skill. Covers 7-stage pipeline (spec/plan/build/test/review/simplify/ship), wave execution, quality gating, and role-based orchestration."
version: 3.0.0
---

# Harness Engineering Skill v3.0 — 多智能体研发协作引擎

> 融合 GSD + GSTACKS + Superpowers 四大研发流程优势，构建统一的全生命周期 AI 研发引擎。
>
> **版本**: 3.0.0 (🏗️ **架构重构版**)
>
> **更新日期**: 2026-05-06
>
> **v3.0 核心变革**:
> - 🗂️ **文件结构统一**: 消除三重冗余，建立 Single Source of Truth (`core/skills/<stage>/`)
> - ⚙️ **运行时引擎**: Gate 检查、Skill 加载、流水线编排从文档变为可执行代码 (`core/engine/`)
> - 🔌 **技术栈抽象**: 解除 React+TS 绑定，支持 Python/Java/Go (`core/profiles/`)
> - 📈 **Evolution Loop 落地**: 基准任务集 + 四步进化循环可实际运行
> - 📋 **注册表统一**: 5 个分散配置文件合并为 `registry.yaml` + `pipeline.yaml`

## 核心架构

```
┌─────────────────────────────────────────────────────┐
│ L5 进化与度量                                       │
│   Evolution Loop (evaluate→analyze→improve) + Metrics │
├─────────────────────────────────────────────────────┤
│ L4 门控与保障                                       │
│   7-Gate 防御纵深 + Staff Review 6 维              │
│   🔥 v3 新增: 自动化 Gate Runner (可执行!)          │
├─────────────────────────────────────────────────────┤
│ L3 编排与执行                                       │
│   7-Stage Pipeline + Wave 并行执行                 │
│   🔥 v3 新增: Pipeline Executor (可执行!)           │
├─────────────────────────────────────────────────────┤
│ L2 方法论能力库                                     │
│   19+ 个 Skills (按阶段分组于 core/skills/)         │
│   🔥 v3 新增: Tech Profiles (多技术栈支持)          │
├─────────────────────────────────────────────────────┤
│ L1 基础设施                                         │
│   项目模板 + 运行时引擎 + 统一注册表                 │
└─────────────────────────────────────────────────────┘
```

## 7-Stage 增量流水线

```
/harness spec → /harness plan → /harness build → /harness test → /harness review → /harness simplify → /harness ship
     │               │               │               │               │                │                │
     ▼               ▼               ▼               ▼               ▼                ▼                ▼
  Spec Gate      Plan Gate      Build Gate      Test Gate      Review Gate     Simplify Gate     Ship Gate
```

## 6 个 AI 角色

| 角色 | 阶段 | 职责 | 定义文件 |
|------|------|------|----------|
| Product Owner | spec | 需求采访、方案决策、文档审批 | `core/roles/product-owner.md` |
| Architect | plan | 任务拆分、依赖分析、Wave 编排 | `core/roles/architect.md` |
| Implementer | build | TDD 编码、微任务执行 | `core/roles/implementer.md` |
| Tester | test | 测试执行、覆盖率分析、证据收集 | `core/roles/tester.md` |
| Reviewer | review/simplify | 6 维度审查、复杂度分析 | `core/roles/reviewer.md` |
| Shipper | ship | 版本管理、Git 操作、最终把关 | `core/roles/shipper.md` |

## 能力技能库（按阶段组织）

### Spec（产品定义）
| 技能 | 模式 | 强制 | 定义 |
|------|------|------|------|
| brainstorming | Inversion Interview | ✅ | `skills/spec/brainstorming/SKILL.md` |
| deep-requirements | Deep Interview | ❌ | `skills/spec/deep-requirements/SKILL.md` |
| spec-generator | Template Filling | ✅ | `skills/spec/spec-generator/SKILL.md` |
| office-hours | Six-Question Challenge | ❌ | `skills/spec/office-hours/SKILL.md` |

### Plan（架构规划）
| 技能 | 模式 | 强制 | 定义 |
|------|------|------|------|
| writing-plans | Task Decomposition | ✅ | `skills/plan/writing-plans/SKILL.md` |

### Build（构建实现）
| 技能 | 模式 | 强制 | 定义 |
|------|------|------|------|
| tdd | RED-GREEN-REFACTOR | ✅ | `skills/build/tdd/SKILL.md` |
| subagent-driven-dev | Role Isolation | ✅ | `skills/build/subagent-driven-dev/SKILL.md` |
| systematic-debugging | Four-Stage Investigation | ❌ | `skills/build/systematic-debugging/SKILL.md` |

### Test（验证测试）
| 技能 | 模式 | 强制 | 定义 |
|------|------|------|------|
| verification | Evidence Collection | ✅ | `skills/test/verification/SKILL.md` |
| test-generator | Auto Generation | ❌ | `skills/test/test-generator/SKILL.md` |
| e2e-qa | Browser Validation (Obscura) | ❌ | `skills/test/e2e-qa/SKILL.md` |
| qa | Quality Assurance | ❌ | `skills/test/qa/SKILL.md` |

### Review（代码审查）
| 技能 | 模式 | 强制 | 定义 |
|------|------|------|------|
| staff-review | Six-Dimension Checklist | ✅ | `skills/review/staff-review/SKILL.md` |
| code-simplification | Simplification Checklist | ❌ | `skills/review/code-simplification/SKILL.md` |
| requesting-code-review | Review Request | ❌ | `skills/review/requesting-code-review/SKILL.md` |

### Ship（发布上线）
| 技能 | 模式 | 强制 | 定义 |
|------|------|------|------|
| ship-pipeline | Gated Release | ✅ | `skills/ship/ship-pipeline/SKILL.md` |
| gstack-ship | Ship Checklist | ❌ | `skills/ship/gstack-ship/SKILL.md` |

### Cross-Cutting（横切关注）
| 技能 | 职责 | 定义 |
|------|------|------|
| orchestrator | 多角色协作编排器 | `skills/cross-cutting/orchestrator/SKILL.md` |
| gating | 7-Gate 质量门禁 | `skills/cross-cutting/gating/SKILL.md` |
| governance | 治理流程 | `skills/cross-cutting/governance/SKILL.md` |
| memory-management | 记忆管理 | `skills/cross-cutting/memory-management/SKILL.md` |
| onboarding | 快速启动指南 | `skills/cross-cutting/onboarding/SKILL.md` |
| gsd | GSD 工作流 | `skills/cross-cutting/gsd/SKILL.md` |

## 运行时引擎（v3 新增）

位于 `core/engine/`，提供可执行的工程能力：

| 模块 | 文件 | 职责 |
|------|------|------|
| types.ts | 共享类型定义 | Stage, GateResult, SkillManifest 等 |
| schema-validator.ts | 注册表校验 | 一致性检查、格式验证 |
| gate-runner.ts | 门禁检查器 | 自动化 Gate 验证（dry-run / enforce） |
| skill-loader.ts | 技能加载器 | 解析、校验、加载 Skill 定义 |
| pipeline-executor.ts | 流水线执行器 | Stage 编排、Gate 守护、进度追踪 |
| metrics-collector.ts | 度量收集 | Gate 通过率、Token 效率等指标 |

### 快速命令

```bash
# 校验注册表一致性
npx tsx core/engine/schema-validator.ts

# 运行单个 Gate 检查
npx tsx core/engine/gate-runner.ts spec_gate --strictness L2

# 加载并校验所有 Skills
npx tsx core/engine/skill-loader.ts --validate
```

## 技术栈配置（v3 新增）

位于 `core/profiles/`，解除单一技术栈绑定：

| Profile | 适用场景 | 定义文件 |
|---------|---------|----------|
| react-typescript | React + TypeScript + Vite（默认） | `profiles/react-typescript.yaml` |
| python | Python + pytest + ruff | `profiles/python.yaml` |
| java | Java + Maven + JUnit5 | `profiles/java.yaml` |
| go | Go + go test + golangci-lint | `profiles/go.yaml` |

自动检测优先级：`.harness/config.yaml` 显式指定 → 项目文件推断 → generic 兜底。

## Evolution Loop（v3 新增）

位于 `core/engine/evolution/`，四步自改进循环：

```
Evaluate (运行基准任务) → Analyze (蒸馏证据报告) → Improve (基于证据改组件) → Verify (下一轮验证预测)
```

基准任务集：`templates/evolution/benchmark-tasks.yaml`（5 个覆盖端到端能力验证的任务）

## 7-Gate 防御纵深

支持 L1(轻量)/L2(标准)/L3(严格) 三级严格度：

| # | 门禁 | L1 最小检查 | L2 标准检查 | L3 严格检查 |
|---|------|-----------|-----------|-----------|
| 1 | Spec Gate | 设计文档存在 | +审批 + ≥1验收标准 | +≥3验收标准 +方案对比 |
| 2 | Plan Gate | 任务列表存在 | +≤5分钟 +依赖标注 | +风险评估 +工时估算 |
| 3 | Build Gate | 构建通过 | +类型检查 + ≤100行变更 | +安全扫描 |
| 4 | Test Gate | 测试全通过 | +覆盖率≥80% +新代码有测试 | +覆盖率≥90% +突变测试 |
| 5 | Review Gate | 仅自动化检查 | +P0=0 + P1≤3 + lint | +P1≤1 + 安全审查 |
| 6 | Simplify Gate | 无严重复杂度 | +函数≤50行 + 文件≤500行 | +圈复杂度≤10 |
| 7 | Ship Gate | Git干净 + tag | +全部门禁通过 + 构建成功 | +灰度发布计划 |

完整定义：`core/pipeline.yaml`（gates 段）

## 快速开始

```bash
/harness init --template web-react --strictness L2
/harness spec   # 需求定义（MCP 强制交互）
/harness plan   # 架构规划（MCP 强制确认）
/harness build  # 构建实现（Pre-Execution Gate 保护）
/harness test   # 验证测试（Obscura 优先）
/harness review # 代码审查
/harness simplify # 代码简化
/harness ship   # 发布上线

# v3 新增：运行时命令
harness gate check spec_gate --enforce       # 执行 Gate 检查
harness skill validate                       # 校验所有 Skill 格式
harness schema validate                      # 校验注册表一致性
harness evolve run                           # 启动 Evolution Loop
```

## 核心铁律

1. **没有证据不算完成**
2. **找不到根因不能修**
3. **审查者只看不改**
4. **先写测试再写实现**
5. **一次只做一块**（<=100 行 / <=5 分钟）
6. **🔴 所有关键节点必须等待用户确认**（MCP 协议 v2.0）
7. **🌐 E2E 测试优先使用 Obscura 引擎**
8. **⚡ v3 新增：所有 Gate 可自动化执行**（不再仅靠文档约束）

## 文件索引

| 目录 | 内容 | 说明 |
|------|------|------|
| `core/skills/` | 所有技能定义（按阶段分组） | Single Source of Truth |
| `core/roles/` | 6 个 AI 角色定义 | 扁平化 .md 文件 |
| `core/engine/` | 运行时引擎（TypeScript） | v3 新增，可执行 |
| `core/profiles/` | 技术栈配置文件 | v3 新增，多语言支持 |
| `core/registry.yaml` | 统一注册表 | 合并自 3 套旧配置 |
| `core/pipeline.yaml` | 流水线 + 门禁定义 | 合并自 stages + gates |
| `core/memory/` | 长期记忆 | 从 .workbuddy/memory/ 迁移 |
| `templates/` | 项目模板 + Evolution 基准任务 | web-react/ + evolution/ |
| `projects/` | 示例项目 | todo-app, data-dashboard 等 |

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.0.0 | 2026-04-28 | 初始版本 |
| 2.0.0 | 2026-04-30 | 集成 MCP 协议，强化用户交互 |
| 2.1.0 | 2026-05-04 | 新增 Obscura 浏览器引擎集成 |
| 2.2.0 | 2026-05-05 | 质量改进：ESM/CJS统一、依赖锁定、Error Pattern Library |
| **3.0.0** | **2026-05-06** | **架构重构：统一文件结构、运行时引擎、技术栈抽象、Evolution Loop落地** |
